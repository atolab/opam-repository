sh .travis-opam.sh

